#if defined(ON_HARDWARE)

#include <DaisySeedFramework/DaisySeedHAL.h>
typedef DaisySeedHAL PlatformHAL;

#elif defined(ON_WINDOWS)

#include <DaisySeedFramework/WindowsHAL.h>
typedef WindowsHAL PlatformHAL;

#endif

void AudioPassthrough(const float* const* In, float** Out, uint32 Count)
{
	for (uint32 i = 0; i < Count; i++)
	{
		Out[PlatformHAL::CHANNEL_LEFT][i] = In[PlatformHAL::CHANNEL_LEFT][i];
		Out[PlatformHAL::CHANNEL_RIGHT][i] = In[PlatformHAL::CHANNEL_RIGHT][i];
	}
}

int main(void)
{
	PlatformHAL hal;
	hal.Setup(48, SAMPLE_RATE_48000, false);

	hal.StartAudio(AudioPassthrough);

	while (1)
	{
	}
}